let db;
const request = indexedDB.open("DawaDB", 1);

request.onerror = function(event) { console.log("Database error: " + event.target.errorCode); };
request.onsuccess = function(event) { db = event.target.result; };
request.onupgradeneeded = function(event) {
    db = event.target.result;
    db.createObjectStore("gadam", { keyPath: "id", autoIncrement:true });
    db.createObjectStore("customers", { keyPath: "id", autoIncrement:true });
    db.createObjectStore("sales", { keyPath: "id", autoIncrement:true });
    db.createObjectStore("returns", { keyPath: "id", autoIncrement:true });
};

function navigate(page) {
    const view = document.getElementById('view');
    view.innerHTML = '';
    if(page==='gadam'){ view.innerHTML = '<h2>گدام</h2><p>صفحهٔ گدام بارگذاری شد...</p>'; }
    else if(page==='customers'){ view.innerHTML = '<h2>مشتریان</h2><p>لیست مشتریان...</p>'; }
    else if(page==='sell'){ view.innerHTML = '<h2>فروش</h2><p>ثبت فروش نقدی و لیست</p>'; }
    else if(page==='returns'){ view.innerHTML = '<h2>برگشت دوا</h2><p>ثبت برگشت دوا...</p>'; }
    else if(page==='reports'){ view.innerHTML = '<h2>گزارشات</h2><p>نمایش گزارشات...</p>'; }
    else if(page==='settings'){ view.innerHTML = '<h2>تنظیمات</h2><p>تنظیمات اپ</p>'; }
}